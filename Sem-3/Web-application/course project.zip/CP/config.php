<?php
$username='root';
$password='';
$db_name='login';
$host='localhost';
$conn=mysqli_connect($host,$username,$password,$db_name);
?>